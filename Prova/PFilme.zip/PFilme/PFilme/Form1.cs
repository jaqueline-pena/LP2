﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualBasic;
using System.Windows.Forms;


namespace PFilme
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            double[,] notafilme = new double[10, 2];
            string notas;
            double media1=0, media2=0;
            int lin, col;


            for (lin = 0; lin < 10; lin++)
            {
                for (col = 0; col < 2; col++)
                {

                    notas = Interaction.InputBox("Pessoa: " + (lin + 1).ToString() + " Insira a nota do filme: " + (col + 1).ToString(), "Notas Filmes");

                    if (!double.TryParse(notas, out notafilme[lin, col]))
                    {
                        MessageBox.Show("Nota Inválida");
                        col--;
                    }
                    else
                    {
                        if (!(notafilme[lin, col] >= 0 && notafilme[lin, col] <= 10)) //verificação se o usuário digitou algum número menor do que 0 ou maior do que 10
                        {
                            MessageBox.Show("Nota Inválida");
                            col--;
                        }
                        else
                        {
                            while (notafilme[lin, col] <= 0)
                            {
                                notas = "";
                                notas = Interaction.InputBox("Pessoa: " + (lin + 1).ToString() + " Insira a nota do filme: " + (col + 1).ToString(), "Notas Filmes");

                                if (!double.TryParse(notas, out notafilme[lin, col]))
                                {
                                    MessageBox.Show("Preço Inválido");
                                }
                            }
                        }
                    }
                    lbxNotas.Items.Add("Pessoa: " + (lin + 1).ToString() + "Nota Filme: " + (col + 1).ToString() + notas + "Nota Filme: " + (col + 2).ToString() + notas);

                }

                media1 += ((notafilme[lin, 0]));
                media2 += ((notafilme[lin, 1]));
            }
            media1 = media1 / 10;
            media2 = media2 / 10;
           

            lbxNotas.Items.Add("Média Filme 1: " + media1.ToString("N2") + "Média Filme 2: " + media2.ToString("N2")); 

        }
    }
}
